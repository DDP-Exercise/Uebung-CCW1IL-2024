$(document).ready(function () {
    // Laden der Umfrageergebnisse


    // Event-Handler für das Löschen von Einträgen
    $(document).on('click', '.deleteBtn', function () {

    });

    // Funktion zum Löschen eines Eintrags
    function deleteResult(index) {

    }
});
