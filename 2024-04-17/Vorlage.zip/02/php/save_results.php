<?php
// Prüfen, ob POST-Daten vorhanden sind
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['results'])) {

} else {
    // Fehlermeldung, wenn keine POST-Daten vorhanden sind

}
?>
