<?php
// Pfad zur Datei, in der die Ergebnisse gespeichert werden sollen
$file_path = '../json/survey_results.json'; // Pfade relativ zum Verzeichnis dieses Skripts anpassen

// Prüfen, ob POST-Daten vorhanden sind
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Index des zu löschenden Eintrags aus POST-Daten abrufen


} else {

}
?>
