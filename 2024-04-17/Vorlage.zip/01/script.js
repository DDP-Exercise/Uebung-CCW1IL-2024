class Contact {
    constructor(name, phone, email) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }
}

$(document).ready(function() {
    const contactList = [];


    function displayContacts() {

    }

    $('#contactList').on('click', '.delete-btn', function() {

    });

    function saveContacts() {

    }
});
