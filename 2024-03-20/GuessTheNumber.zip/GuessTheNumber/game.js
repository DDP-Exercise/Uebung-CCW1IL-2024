// Variable declarations
let counter = 0;
let randomNumber = 0;
let numberOfAttempts = 0;
let guessedNumber = 0;

// Get DOM elements
const outputField = document.getElementById('output');
const guessButton = document.querySelector("#guessNumberForm .btn");


// Function to generate a random number and update the display
function generateRandomNumber() {

}

// Function to update the number of attempts and change the display
function updateNumberOfAttempts() {

}

// Function to guess a number and update the display
function guessNumber() {

}

// Function to check if the user has consumed all attempts and update the display accordingly
function checkLost() {

}

// Function to prevent the default behavior of the form and call the appropriate function
function submitForm(event) {
     // Prevent default behavior

    // Call the appropriate function based on the submitted form

}

// Add event listeners for the forms
